for i in {1..20..1}
do
    ./max 50 10
done
